package com.icesoft.icefaces.samples.security;

public class Server {

    protected Queues queues;
    //Array required to populate queuesStatistics dataTable component in UI
    private Queues[] queuesStatistics = new Queues[1];
    private String name;
    protected Servers servers;

    //  Simulated server data
    protected String[] clientLevel1QueueNames = {"ICESV.CRD.Q1","ICESV.CREDIT.CARD.ENGINE.Q1",
            "ICESV.ERROR.CORRECTION.Q1","ICESV.METER.UPLOAD.RESOLUTION.Q1","ICESV.PUBDATA.Q1",
            "ICESV.REV.RI.MPS","ICESV.RSF.Q1","TEST.SELECTOR.QUEUE1","TEST.SELECTOR.QUEUE2",
            "TEST.SELECTOR.QUEUE3","TEST.XA.GENESIS.GDD","Z.STEVE.TEST","queue.sample","sample"
    };
    protected String[] topSecretQueueNames = {"TS.CRD.Q1","TS.CREDIT.CARD.ENGINE.Q1",
            "TS.ERROR.CORRECTION.Q1","TS.METER.UPLOAD.RESOLUTION.Q1","TS.PUBDATA.Q1",
            "TS.REV.RI.MPS","TS.RSF.Q1"
    };

    public Server(String name){
        this.name=name;
        if(name.contains("Client-Level"))
            queues = new Queues(clientLevel1QueueNames);
        if(name.equals("Top-Secret"))
            queues = new Queues(topSecretQueueNames);
        queuesStatistics[0] = queues;
    }
    
    public void init(Servers servers){
        this.servers = servers;
        queues.init(this);
    }

    //Getters
    public Queues getQueues() { return queues; }
    public String getName() { return name; }
    public Queues[] getQueuesStatistics() { return queuesStatistics; }

    //Setters 
    public void setQueues(Queues queues) {
        this.queuesStatistics[0] = queues;
        this.queues = queues;
    }
    public void setName(String name) { this.name = name; }
    public void setQueuesStatistics(Queues[] queuesStatistics) { this.queuesStatistics = queuesStatistics; }

}
