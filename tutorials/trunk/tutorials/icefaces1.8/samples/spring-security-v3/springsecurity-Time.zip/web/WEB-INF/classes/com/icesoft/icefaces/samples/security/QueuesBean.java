package com.icesoft.icefaces.samples.security;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.icesoft.faces.component.datapaginator.DataPaginator;

/**
 * Queues session scope, view specific data.
 */

public class QueuesBean extends SortableList{

    // list of queueBeans
    protected ArrayList queueBeans;
    
    // sort column names
    private static String queueNameColumnName = "Queue Name";
    private static String rcvrsColumnName = "Rcvrs";
    private static String msgsColumnName = "Msgs";
    private static String sizeColumnName = "Size";

    // comparator used to sort queues.
    private Comparator comparator;
    
    private DataPaginator dataPaginator;

    public QueuesBean(Server selectedServer, DataPaginator dataPaginator){
        // default sort header
        super(queueNameColumnName);
        this.dataPaginator = dataPaginator;
        queueBeans = new ArrayList();
        for(int i=0; i<selectedServer.queues.queues.size(); i++){
            QueueBean temp = new QueueBean((Queue)selectedServer.queues.queues.get(i));
            queueBeans.add(temp);
        }

    }
    
    //Getters
    public String getQueueNameColumnName() { return queueNameColumnName; }
    public String getRcvrsColumnName() { return rcvrsColumnName; }
    public String getMsgsColumnName() { return msgsColumnName; }
    public String getSizeColumnName() { return sizeColumnName; }
    public DataPaginator getDataPaginator() { return dataPaginator; }

    public void setDataPaginator(DataPaginator dataPaginator) { this.dataPaginator = dataPaginator; }

    public ArrayList getQueueBeans() {

        if (!oldSort.equals(sort) ||
                oldAscending != ascending){
             sort();
             oldSort = sort;
             oldAscending = ascending;

             if(dataPaginator!=null && dataPaginator.getUIData() != null){
                 if(dataPaginator.getPageCount()<=1){
                     return queueBeans;
                 }
                 else{
                     dataPaginator.gotoFirstPage();
                     int pageCount = dataPaginator.getPageCount();
                     int rows = dataPaginator.getRows();
                     int expandedRowNumber = 0;
                     for(int i=0; i<queueBeans.size(); i++){
                         if(((QueueBean)queueBeans.get(i)).isExpanded()){
                             expandedRowNumber=i+1;
                         }
                     }
                     if(expandedRowNumber > rows){
                         for(int y=1; y<pageCount; y++){
                             dataPaginator.gotoNextPage();
                             for(int z=1; z<=rows; z++){
                                 if((y*rows+z)==expandedRowNumber){
                                     break;
                                 }
                             }
                         }
                     }
                 }
            }
        }

        return queueBeans;
    }
    
    /**
     * Sort the list.
     */
    protected void sort() {

        if (comparator == null){
            comparator = new Comparator(){
                public int compare(Object o1, Object o2) {
                    QueueBean c1 = (QueueBean) o1;
                    QueueBean c2 = (QueueBean) o2;
                    if (sort == null) {
                        return 0;
                    }
                    else if (sort.equals(queueNameColumnName)) {
                        return ascending ?
                                c1.getQueue().getQueueName().toLowerCase().compareTo( c2.getQueue().getQueueName().toLowerCase() ):
                                c2.getQueue().getQueueName().toLowerCase().compareTo( c1.getQueue().getQueueName().toLowerCase() );
                    }
                    else if (sort.equals(rcvrsColumnName)) {
                        return ascending ?
                                new Integer(c1.getQueue().getRcvrs()).compareTo( new Integer(c2.getQueue().getRcvrs()) ):
                                new Integer(c2.getQueue().getRcvrs()).compareTo( new Integer(c1.getQueue().getRcvrs()) );
                    }
                    else if (sort.equals(msgsColumnName)) {
                        return ascending ?
                                new Integer(c1.getQueue().getMsgs()).compareTo( new Integer(c2.getQueue().getMsgs()) ):
                                new Integer(c2.getQueue().getMsgs()).compareTo( new Integer(c1.getQueue().getMsgs()) );
                    }
                    else if (sort.equals(sizeColumnName)) {
                        return ascending ?
                                new Double(c1.getQueue().getSize()).compareTo( new Double(c2.getQueue().getSize()) ):
                                new Double(c2.getQueue().getSize()).compareTo( new Double(c1.getQueue().getSize()) );
                    }
                    else return 0;
                }
            };
        }

        Collections.sort(queueBeans, comparator);

    }

    /**
     * Is the default sort direction for the given column "ascending" ?
     */
    protected boolean isDefaultAscending(String sortColumn) {
        return true;
    }

}
