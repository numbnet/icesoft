package com.icesoft.icefaces.samples.security;

public class Servers {
    
    private Server[] servers;
    protected ClientController clientController;

    public Servers(){
        //This is where the JMS servers will have to be queried for a list of servers.        
        servers = new Server[]{new Server("Top-Secret"),
                               new Server("Alabama-Client-Level1"),
                               new Server("Delaware-Client-Level2"),
                               new Server("Hawaii-Client-Level3"),
                               new Server("Louisiana-Client-Level4"),
                               new Server("Oregon-Client-Level5"),
                               new Server("Vermont-Client-Level6")};
        
    }
    
    public void init(ClientController clientController){
        this.clientController = clientController;
        for(int i=0; i<servers.length; i++){
            servers[i].init(this);
        }
    }

    //Getters
    public Server[] getServers() { return servers; }

    //Setters
    public void setServers(Server[] servers) { this.servers = servers; }

}
