/**
 * Copyright (C) 2005, ICEsoft Technologies Inc.
 */
package com.icesoft.icefaces.samples.security;

/**
 * The SortableList class is a utility class required to make the 
 * ice:commandSortHeader and ice:datatPaginator components work in conjunciton 
 * with the ice:dataTable component.
 *
 * @since 0.3.0
 */
public abstract class SortableList {

    protected String sort;
    protected boolean ascending;

    protected String oldSort;
    protected boolean oldAscending;


    protected SortableList(String defaultSortColumn) {
        sort = defaultSortColumn;
        ascending = isDefaultAscending(defaultSortColumn);
        oldSort = sort;
        oldAscending = ascending;
    }

    /**
     * Sort the list.
     */
    protected abstract void sort();

    /**
     * Is the default sort direction for the given column "ascending" ?
     */
    protected abstract boolean isDefaultAscending(String sortColumn);


    /**
     * Gets the sort column.
     *
     * @return column to sort
     */
    public String getSort() {
        return sort;
    }

    /**
     * Sets the sort column
     *
     * @param sort column to sort
     */
    public void setSort(String sort) {
        oldSort = this.sort;
        this.sort = sort;

    }

    /**
     * Is the sort ascending.
     *
     * @return true if the ascending sort otherwise false.
     */
    public boolean isAscending() {
        return ascending;
    }

    /**
     * Set sort type.
     *
     * @param ascending true for ascending sort, false for desending sort.
     */
    public void setAscending(boolean ascending) {
        oldAscending = this.ascending;
        this.ascending = ascending;
    }
}
