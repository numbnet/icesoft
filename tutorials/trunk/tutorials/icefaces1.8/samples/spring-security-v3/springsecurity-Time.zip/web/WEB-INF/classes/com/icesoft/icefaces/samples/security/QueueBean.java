package com.icesoft.icefaces.samples.security;

import javax.faces.event.ValueChangeEvent;

/**
 * Queue session scope, view specific data.
 */

public class QueueBean {

    private Queue queue;

    private boolean expanded = false;
    
    protected boolean selected = false;

    public QueueBean(Queue queue){
        this.queue = queue;    
    }
    
    // Getters
    public Queue getQueue() { return queue; }
    public boolean isExpanded() { return expanded; }
    public boolean isSelected() { return selected; }

    // Setters
    public void setQueue(Queue queue) { this.queue = queue; }
    public void setExpanded(boolean expanded) { this.expanded = expanded; }
    public void setSelected(boolean selected) { this.selected = selected; }

    public void selectedChanged(ValueChangeEvent e){
        expanded = !expanded;
    }
}
