package com.icesoft.icefaces.samples.security;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority; 

import com.icesoft.faces.async.render.Renderable;
import com.icesoft.faces.webapp.xmlhttp.FatalRenderingException;
import com.icesoft.faces.webapp.xmlhttp.PersistentFacesState;
import com.icesoft.faces.webapp.xmlhttp.RenderingException;
import com.icesoft.faces.webapp.xmlhttp.TransientRenderingException;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.Authentication;

import java.util.Collection;
import java.util.Iterator;

/**
 * User Model Class.
 */
public class User implements Renderable, HttpSessionListener {

    private static Log log = LogFactory.getLog(User.class);
    
    protected String userName;
    protected String role;
    protected int roleNumber;
    private AuthenticationManager am; 

    protected ClientController clientController;
    // Local instance of the persistent faces state, required by the render api
    // this var must be thread local.
    private PersistentFacesState persistentFacesState;
    
    private static boolean initialized = false;
    
    public User(){
        persistentFacesState = PersistentFacesState.getInstance();
        log.debug("constructor " + persistentFacesState.toString());
        // For some reason, this flag is always true after the first login, even though User bean is session scoped. 
//        if(!initialized){
            initializeApplication();
//            initialized = true;
//        }
    }

    public void initializeApplication(){
//        ((ClientController)persistentFacesState.getFacesContext().getApplication().getVariableResolver().resolveVariable(persistentFacesState.getFacesContext(), "clientController")).init();
         SecurityContext sc = SecurityContextHolder.getContext();
        Authentication a = sc.getAuthentication();

        role = "";
        if (a != null) {
            userName = a.getName();
            Collection gas = a.getAuthorities();
            Iterator i = gas.iterator();
            GrantedAuthority ga;
            while (i.hasNext()) {
                ga = (GrantedAuthority) i.next();
                    role += ga.getAuthority() + " ";
            }
        }
    }
    
    //Getters
    /**
     * Runnable interface call back for this class persistent faces tate.
     *
     * @return persistent faces state of this class.
     */
    public PersistentFacesState getState() { return persistentFacesState; }

    public String getUserName() {
        persistentFacesState = PersistentFacesState.getInstance();
        return userName; 
    }
    public String getRole() { return role; }
    public ClientController getClientController(){ return clientController; }

    //Setters
    public void setUserName(String userName) { this.userName = userName; }
    public void setRole(String role) { this.role = role; }
    public void setClientController(ClientController clientController) { this.clientController = clientController; }
    
    /**
     * Callback method that is called if any exception occurs during an attempt
     * to render this Renderable.
     *
     * @param renderingException The exception that occurred when attempting
     * to render this Renderable.
     */
    public void renderingException(RenderingException renderingException) {

        if (log.isDebugEnabled() &&
                renderingException instanceof TransientRenderingException ){
            log.debug("Transient Rendering exception:", renderingException);

            clientController.removeFromRenderer(this);
        }
        else if(renderingException instanceof FatalRenderingException){
            if (log.isDebugEnabled()) {
                log.debug("Fatal rendering exception: ", renderingException);
            }

            clientController.removeFromRenderer(this);
        }
    }
    
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {

    }

    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
        if (log.isDebugEnabled()){
            log.debug("Servlet Context Distroyed");
        }
        clientController.removeFromRenderer(this);
        log.debug("Removing User from Renderer");
    }

    public AuthenticationManager getAm() {
        return am;
    }

    public void setAm(AuthenticationManager am) {
        this.am = am;
    }
}
