package com.icesoft.icefaces.samples.security;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.icesoft.faces.component.datapaginator.DataPaginator;
import com.icesoft.faces.component.selectinputtext.SelectInputText;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * UserBean class extends the User class, any View specific instance var
 * should go here any thing else should go in the base model class.
 */
public class UserBean extends User {
    
    private static Log log = LogFactory.getLog(UserBean.class);    
    // List for autocomplete component
    private List serverList;
    // List of possible matches for autocomplete component.
    private List matchesList = new ArrayList();
    // Comparator utility for sorting SelectItem labels in autocomplete component.
    public static final Comparator LABEL_COMPARATOR = new Comparator() {
        String s1;
        String s2;
        // compare method for entries.
        public int compare(Object o1, Object o2) {
            s1 = ((SelectItem) o1).getLabel();
            if (o2 instanceof SelectItem) {
                s2 = ((SelectItem) o2).getLabel();
            } else {
                s2 = o2.toString();
            }
            // compare ingnoring case, give the user a more automated feel when typing
            return s1.compareToIgnoreCase(s2);
        }
    };
    // Controls rendering of ice:panelGroup component
    protected boolean serverSelected = false;

    // selected Server.
    protected Server selectedServer;
    private QueuesBean queuesBean;
    
    // select all, set to true if all queues are in the selected state.
    private boolean selectedAll = false;
    
    private DataPaginator dataPaginator;

    //Getters
    /**
     * The the list of possible matches for the given SelectInputText value
     * @return list of possible matches.
     */
    public List getList() { return matchesList; }
    public boolean isServerSelected() { return serverSelected; }
    public Server getSelectedServer() { return selectedServer; }
    public QueuesBean getQueuesBean() { return queuesBean; }
    public boolean isSelectedAll() { return selectedAll; }
    public DataPaginator getDataPaginator() { return dataPaginator; }

    //Setters
    public void setServerSelected(boolean serverSelected) { this.serverSelected = serverSelected; }
    public void setSelectedServer(Server selectedServer) { this.selectedServer = selectedServer; }
    public void setQueuesBean(QueuesBean queuesBean) { this.queuesBean = queuesBean; }
    public void setSelectedAll(boolean selectedAll) { this.selectedAll = selectedAll; }
    public void setDataPaginator(DataPaginator dataPaginator) { this.dataPaginator = dataPaginator; }

    /**
     * Called when a user has modifed the SelectInputText value.  This method
     * call causes the match list to be updated.
     * @param event
     */
    public void updateList(ValueChangeEvent event)  {

        // get a new list of matches.
        setMatches(event);
        // Get the auto complete component from the event
        if (event.getComponent() instanceof SelectInputText ) {
            SelectInputText autoComplete = (SelectInputText)event.getComponent();
            // if there is a selected item get the value from the match list.
            if (autoComplete.getSelectedItem()!= null){
                selectedServer = (Server) autoComplete.getSelectedItem().getValue();
                serverSelected = true;
                initView();
                clientController.removeFromRenderer(this);
                clientController.addToRenderer(this);
            }
            // otherwise if no selected item then return the previously selected item.
            else{
                Server tempServer = getMatch(autoComplete.getValue().toString());
                if(tempServer != null){
                    selectedServer = tempServer;
                }
            }
        }
    }
    
    private Server getMatch(String value){
        Server result = null;
        if (matchesList != null){
            SelectItem si;
            Iterator iter = matchesList.iterator();
            while(iter.hasNext()){
                si = (SelectItem)iter.next();
                if(value.equals(si.getLabel())){
                    result = (Server)si.getValue();
                }
            }
        }
        return result;
    }
    
    /**
     * Utility method for building the match list given the current value
     * of the SelectInputText component.
     * @param event
     */
    // maxMatches hard coded because of JIRA ICE-1320
    int maxMatches = 15;
    private void setMatches(ValueChangeEvent event) {
        Object searchWord = event.getNewValue();
        //int maxMatches = ((SelectInputText)event.getComponent()).getRows();
        List matchList = new ArrayList(maxMatches);
        try {
            int insert = Collections.binarySearch(serverList, searchWord,
                    LABEL_COMPARATOR);
            // less then zero if we have a partial match
            if (insert < 0){
                insert = Math.abs(insert) -1;
            }
            for (int i=0; i < maxMatches; i++)  {
                // quit the match list creation if the index is larger then
                // max entries in the dictionary of we have added maxMatches.
                if ((insert + i) >= serverList.size() ||
                        i >= maxMatches){
                    break;
                }
                matchList.add( serverList.get(insert + i));
            }
        } catch (Throwable e)  {
            log.error("Error finding autocomplete matches", e);
        }
        // assign new matchList
        if (this.matchesList != null){
            this.matchesList.clear();
            this.matchesList = null;
        }
        this.matchesList = matchList;
    }
    
    public void initRole(Authentication auth){
        
        Object obj = auth.getPrincipal();
        if (obj instanceof UserDetails) {
            userName = ((UserDetails)obj).getUsername();
            Collection grantedAuthorities =  ((UserDetails)obj).getAuthorities();
            Iterator i = grantedAuthorities.iterator();

            if (i.hasNext()) {
                GrantedAuthority temp = (GrantedAuthority) i.next();
                role = temp.getAuthority();
            }
        } else {
            userName = obj.toString();
        }

        if(role.equals("ROLE_SUPERVISOR")){
            roleNumber = 1;
        }
        if(role.equals("ROLE_USER")){
            roleNumber = 2;
        }
        // serverList is required to bind data to the autocomplete component.
        serverList = clientController.getServerList(roleNumber);
        // Sort the list
        Collections.sort(serverList, LABEL_COMPARATOR);
        for(int i=0; i<serverList.size(); i++){
            matchesList.add(serverList.get(i));
        }
    }

    /**
     * Sets the selected property on all Queue objects contained in Queues.
     */
    public void selectAll(ActionEvent event){
        selectedAll = !selectedAll;
        if (queuesBean.queueBeans != null && queuesBean.queueBeans.size() > 0){
            for (int i=0; i<queuesBean.queueBeans.size(); i++){
                ((QueueBean)queuesBean.queueBeans.get(i)).setSelected(selectedAll);
            }
        }
    }
   
    public void  purgeSelected(ActionEvent event) {
        boolean purging = false;
        if (queuesBean.queueBeans != null && queuesBean.queueBeans.size() > 0){
            for (int i=0; i<queuesBean.queueBeans.size(); i++){
                QueueBean temp = (QueueBean)queuesBean.queueBeans.get(i);
                if (temp.isSelected()){
                    temp.getQueue().purgeMessages();
                    purging = true;
                }
            }
            if(purging){
                clientController.requestRender(selectedServer.getName());
            }
        }
    }
    
    private void initView(){
        queuesBean = new QueuesBean(selectedServer,dataPaginator);
    }

}
