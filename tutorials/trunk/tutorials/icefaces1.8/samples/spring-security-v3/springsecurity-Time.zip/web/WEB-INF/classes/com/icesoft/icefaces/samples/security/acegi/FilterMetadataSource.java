package com.icesoft.icefaces.samples.security.acegi;

import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;

import java.util.Collection;
import java.util.ArrayList;

/**
 * Implementation of an interface that holds the Filter configuration string
 * rather than having it in the applicationContext.xml file.
 */
public class FilterMetadataSource implements
                                  FilterInvocationSecurityMetadataSource {

    private ArrayList returnVal;

    public FilterMetadataSource() {
         returnVal = new ArrayList();
         ConfigAttribute ca = new SecurityConfig("CONVERT_URL_TO_LOWERCASE_BEFORE_COMPARISON\n" +
                                                 "PATTERN_TYPE_APACHE_ANT\n" +
                                                 "/secure/extreme/**=ROLE_SUPERVISOR\n" +
                                                 "/secure/**=IS_AUTHENTICATED_REMEMBERED\n" +
                                                 "/**=IS_AUTHENTICATED_ANONYMOUSLY" );
         returnVal.add( ca );
    }

    /**
     * Accesses the <code>ConfigAttribute</code>s that apply to a given secure object.
     * <p>
     * Returns <code>null</code> if no attributes apply.
     *
     * @param object the object being secured
     *
     * @return the attributes that apply to the passed in secured object or null if there are no applicable attributes.
     *
     * @throws IllegalArgumentException if the passed object is not of a type supported by the
     *         <code>SecurityMetadataSource</code> implementation
     */
    public Collection getAttributes(Object object) throws IllegalArgumentException {


         System.out.println("____--_-_---__--__ Getting config attributes for: " + object);
         return returnVal;
    } 

    /**
     * If available, returns all of the <code>ConfigAttribute</code>s defined by the implementing class.
     * <p>
     * This is used by the {@link org.springframework.security.access.intercept.AbstractSecurityInterceptor} to perform startup time validation of each
     * <code>ConfigAttribute</code> configured against it.
     *
     * @return the <code>ConfigAttribute</code>s or <code>null</code> if unsupported
     */
    public Collection getAllConfigAttributes() {

         System.out.println("____--_-_---__--__ Getting ALL CONFIG ATTRIBUTES");
         return returnVal;

    } 

    /**
     * Indicates whether the <code>SecurityMetadataSource</code> implementation is able to provide
     * <code>ConfigAttribute</code>s for the indicated secure object type.
     *
     * @param clazz the class that is being queried
     *
     * @return true if the implementation can process the indicated class
     */
    public boolean supports(Class clazz) {
         System.out.println("____--_-_---__--__ CHECKING SUPPORTS FOR: " + clazz);
         return true;

    } 
}
