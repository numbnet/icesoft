/**
 * Copyright (C) 2006, ICEsoft Technologies Inc.
 */
package com.icesoft.icefaces.samples.security;

import java.util.List;
import java.util.ArrayList;
import javax.faces.model.SelectItem;

/**
 * <p>The StyleBean class is the backing bean which manages the demonstrations
 * active theme.  There are currently two themes supported by the bean; XP and
 * Royale. </p>
 *
 * <p>The webpages' style attributes are modified by changing link in the header
 * of the HTML document.  The selectInputDate and tree components' styles are changed
 * by changing the location of their image src directories.</p>
 *
 * @since 0.3.0
 */
public class StyleBean {

    // possible theme choices
    private final String XP = "xp";
    private final String ROYALE = "royale";

    // default theme
    private String currentStyle = XP;
    private String tempStyle = XP;

    // available style list
    private ArrayList styleList;

    // default theme image directory for selectinputdate and theme.
    private String imageDirectory = "./xmlhttp/css/xp/css-images/";

    // folder icons for the respective themes
    public static final String XP_BRANCH_EXPANDED_ICON =  "xmlhttp/css/xp/css-images/tree_folder_open.gif";
    public static final String XP_BRANCH_CONTRACTED_ICON =  "xmlhttp/css/xp/css-images/tree_folder_close.gif";
    public static final String ROYALE_BRANCH_EXPANDED_ICON =  "xmlhttp/css/royale/css-images/tree_folder_open.gif";
    public static final String ROYALE_BRANCH_CONTRACTED_ICON =  "xmlhttp/css/royale/css-images/tree_folder_close.gif";

    /**
     * Creates a new instance of the StyleBean.
     */
    public StyleBean() {
        // initialize dthe style list
        styleList = new ArrayList();
        styleList.add(new SelectItem(XP, XP));
        styleList.add(new SelectItem(ROYALE, ROYALE));
    }

    /**
     * Gets the current style.
     *
     * @return current style
     */
    public String getCurrentStyle() {
        return currentStyle;
    }

    /**
     * Sets the current style of the application to one of the predetermined themes.
     *
     * @param currentStyle
     */
    public void setCurrentStyle(String currentStyle) {
        this.tempStyle  = currentStyle;
    }

    /**
     * Gets the html needed to insert a valid css link tag.
     *
     * @return the tag information needed for a valid css link tag
     */
    public String getStyle(){
        return "<link rel='stylesheet' type='text/css' href='./../xmlhttp/css/"+
                currentStyle +"/"+ currentStyle + ".css"  +"'/>";
    }

    /**
     * Gets the image directory to use for the selectinputdate and tree theming.
     *
     * @return image directory used for theming
     */
    public String getImageDirectory(){
        return imageDirectory;
    }

    /**
     * Applies temp style to to the currnet style and image directory and
     * manually refreshes the icons in the navigation tree.
     * The page will reload based on navigation rules to ensure the theme is applied;
     * this is necessary because of difficulties encountered by
     * updating the stylesheet reference within the <HEAD> of the document.
     *
     * @return the reload navigation attribute
     */
    public String changeStyle(){
        currentStyle = tempStyle;
        imageDirectory = "./xmlhttp/css/" + currentStyle  + "/css-images/";

        return "reload";
    }

    /**
     * Gets a list of available theme names that can be applied.
     *
     * @return available theme list
     */
    public List getStyleList(){
        return styleList;
    }

}