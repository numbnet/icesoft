package com.icesoft.icefaces.samples.security;

import java.util.Random;

import com.icesoft.faces.context.effects.Appear;
import com.icesoft.faces.context.effects.Effect;

public class Queue {
    
    //General queue information
    private String queueName ="";
    private int rcvrs = 0;
    private int msgs = 0;
    private double size = 0;
    
    //Queue statistics
    private int deliveredMsgs = 0;
    private int inTransitMsgs = 0;
    private int maxDelivered = 0;
    private int prefetch = 0;
    private int liveConsumers = 0;
    
    protected Effect rcvrsEffect;
    protected Effect msgsEffect;
    protected Effect sizeEffect;
    protected Effect deliveredMsgsEffect;
    protected Effect inTransitMsgsEffect;
    protected Effect maxDeliveredEffect;
    protected Effect prefetchEffect;
    protected Effect liveConsumersEffect;

    //Getters
    public int getDeliveredMsgs() { return deliveredMsgs; }
    public int getInTransitMsgs() { return inTransitMsgs; }
    public int getLiveConsumers() { return liveConsumers; }
    public int getMaxDelivered() { return maxDelivered; }
    public int getMsgs() { return msgs; }
    public int getPrefetch() { return prefetch; }
    public String getQueueName() { return queueName; }
    public int getRcvrs() { return rcvrs; }
    public double getSize() { return size; }
    public Effect getRcvrsEffect() { return rcvrsEffect; }
    public Effect getMsgsEffect() { return msgsEffect; }
    public Effect getSizeEffect() { return sizeEffect; }
    public Effect getDeliveredMsgsEffect() { return deliveredMsgsEffect; }
    public Effect getInTransitMsgsEffect() { return inTransitMsgsEffect; }
    public Effect getMaxDeliveredEffect() { return maxDeliveredEffect; }
    public Effect getPrefetchEffect() { return prefetchEffect; }
    public Effect getLiveConsumersEffect() { return liveConsumersEffect; }

    //Setters
    public void setDeliveredMsgs(int deliveredMsgs) { this.deliveredMsgs = deliveredMsgs; }
    public void setInTransitMsgs(int inTransitMsgs) { this.inTransitMsgs = inTransitMsgs; }
    public void setLiveConsumers(int liveConsumers) { this.liveConsumers = liveConsumers; }
    public void setMaxDelivered(int maxDelivered) { this.maxDelivered = maxDelivered; }
    public void setMsgs(int msgs) { this.msgs = msgs; }
    public void setPrefetch(int prefetch) { this.prefetch = prefetch; }
    public void setQueueName(String queueName) { this.queueName = queueName; }
    public void setRcvrs(int rcvrs) { this.rcvrs = rcvrs; }
    public void setSize(double size) { this.size = size; }
    public void setRcvrsEffect(Effect rcvrsEffect) { this.rcvrsEffect = rcvrsEffect; }
    public void setMsgsEffect(Effect msgsEffect) { this.msgsEffect = msgsEffect; }
    public void setSizeEffect(Effect sizeEffect) { this.sizeEffect = sizeEffect; }
    public void setDeliveredMsgsEffect(Effect deliveredMsgsEffect) { this.deliveredMsgsEffect = deliveredMsgsEffect; }
    public void setInTransitMsgsEffect(Effect inTransitMsgsEffect) { this.inTransitMsgsEffect = inTransitMsgsEffect; }
    public void setMaxDeliveredEffect(Effect maxDeliveredEffect) { this.maxDeliveredEffect = maxDeliveredEffect; }
    public void setPrefetchEffect(Effect prefetchEffect) { this.prefetchEffect = prefetchEffect; }
    public void setLiveConsumersEffect(Effect liveConsumersEffect) { this.liveConsumersEffect = liveConsumersEffect; }

    // used to generate simluated data
    protected static Random random = new Random(System.currentTimeMillis());
    // counts the number of times through the update loop, this helps generate
    // the simulated data.
    private int statusLoopCount = 0;
    
    protected Queues queues;
    
    public void init(Queues queues){
        this.queues = queues;
    }

    public void generateData(String queueNameIn) {
        // create some random data
        queueName = queueNameIn;
        rcvrs = random.nextInt(5);
        msgs = random.nextInt(10);
        size = random.nextInt(500);
        
        deliveredMsgs = random.nextInt(5);
        inTransitMsgs = random.nextInt(5);
        maxDelivered = random.nextInt(50);
        prefetch = random.nextInt(10);
        liveConsumers = random.nextInt(5);
    }
    
    public void updateStatus() {
        if(random.nextInt(2) == 1){
            statusLoopCount ++;
            // update data
            if (statusLoopCount % 7 == 0){
                rcvrs += 1;
                rcvrsEffect = new Appear();
                rcvrsEffect.setDuration(.5f);
                msgs += 2;
                msgsEffect = new Appear();
                msgsEffect.setDuration(.5f);
                size += 400;
                sizeEffect = new Appear();
                sizeEffect.setDuration(.5f);
                
                deliveredMsgs += 1;
                deliveredMsgsEffect = new Appear();
                deliveredMsgsEffect.setDuration(.5f);
                prefetch += 1;
                prefetchEffect = new Appear();
                prefetchEffect.setDuration(.5f);
            }
            else if (statusLoopCount % 5 == 0){
                if(msgs>0 && size>200){
                    msgs -= 1;
                    msgsEffect = new Appear();
                    msgsEffect.setDuration(.5f);
                    size -= 200;
                    sizeEffect = new Appear();
                    sizeEffect.setDuration(.5f);
                }
                maxDelivered += 1;
                maxDeliveredEffect = new Appear();
                maxDeliveredEffect.setDuration(.5f);
            }
            else if (statusLoopCount % 3 == 0 && msgs>5){
                msgs += 1;
                msgsEffect = new Appear();
                msgsEffect.setDuration(.5f);
                size += 200;
                sizeEffect = new Appear();
                sizeEffect.setDuration(.5f);
                
                inTransitMsgs += 1;
                inTransitMsgsEffect = new Appear();
                inTransitMsgsEffect.setDuration(.5f);
                liveConsumers += 1;
                liveConsumersEffect = new Appear();
                liveConsumersEffect.setDuration(.5f);
            }
        }
    }
    
    public boolean purgeMessages(){
        msgs = 0;
        size = 0;
        return true;
    }
    
}
