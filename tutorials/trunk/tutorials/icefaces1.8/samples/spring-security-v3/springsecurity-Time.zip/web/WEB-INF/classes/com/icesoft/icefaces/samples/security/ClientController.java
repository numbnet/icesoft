package com.icesoft.icefaces.samples.security;

import com.icesoft.faces.async.render.OnDemandRenderer;
import com.icesoft.faces.async.render.RenderManager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.faces.model.SelectItem;

/**
 * This is the controlling class for the applicaiton.
 * The faces-config.xml is used to construct this class.
 */

public class ClientController {

    // Set in faces.config
    protected RenderManager renderManager;
    // OnDemandRenderers, one for each simulated Server.
    protected OnDemandRenderer onDemandRendererClientLevel1;
    protected OnDemandRenderer onDemandRendererClientLevel2;
    protected OnDemandRenderer onDemandRendererClientLevel3;
    protected OnDemandRenderer onDemandRendererClientLevel4;
    protected OnDemandRenderer onDemandRendererClientLevel5;
    protected OnDemandRenderer onDemandRendererClientLevel6;
    protected OnDemandRenderer onDemandRendererTopSecret;
    protected ArrayList renderers;
    // Group names that match the server names.
    // Every User in a group is rendered to by the associated OnDemandRenderer.
    protected static final String CLIENT_LEVEL1_GROUP = "Alabama-Client-Level1";
    protected static final String CLIENT_LEVEL2_GROUP = "Delaware-Client-Level2";
    protected static final String CLIENT_LEVEL3_GROUP = "Hawaii-Client-Level3";
    protected static final String CLIENT_LEVEL4_GROUP = "Louisiana-Client-Level4";
    protected static final String CLIENT_LEVEL5_GROUP = "Oregon-Client-Level5";
    protected static final String CLIENT_LEVEL6_GROUP = "Vermont-Client-Level6";
    protected static final String TOP_SECRET_GROUP = "Top-Secret";
    
    // This is where the simulated data is initially populated.
    protected Servers servers = new Servers();

    public void init(){
        servers.init(this);
    }

    //Getters
    public Date getServerTime() { return Calendar.getInstance().getTime(); }

    //Setters
    /**
     * Sets the renderManager, this called from the faces config.
     * @param renderManager
     */
    public void setRenderManager(RenderManager renderManager) {
        this.renderManager = renderManager;
        renderers = new ArrayList();
        onDemandRendererClientLevel1 =
                renderManager.getOnDemandRenderer( CLIENT_LEVEL1_GROUP );
        renderers.add(onDemandRendererClientLevel1);
        onDemandRendererClientLevel2 =
            renderManager.getOnDemandRenderer( CLIENT_LEVEL2_GROUP );
        renderers.add(onDemandRendererClientLevel2);
        onDemandRendererClientLevel3 =
            renderManager.getOnDemandRenderer( CLIENT_LEVEL3_GROUP );
        renderers.add(onDemandRendererClientLevel3);
        onDemandRendererClientLevel4 =
            renderManager.getOnDemandRenderer( CLIENT_LEVEL4_GROUP );
        renderers.add(onDemandRendererClientLevel4);
        onDemandRendererClientLevel5 =
            renderManager.getOnDemandRenderer( CLIENT_LEVEL5_GROUP );
        renderers.add(onDemandRendererClientLevel5);
        onDemandRendererClientLevel6 =
            renderManager.getOnDemandRenderer( CLIENT_LEVEL6_GROUP );
        renderers.add(onDemandRendererClientLevel6);
        onDemandRendererTopSecret =
            renderManager.getOnDemandRenderer( TOP_SECRET_GROUP );
        renderers.add(onDemandRendererTopSecret);
    }

    // When a server updates data, it calls this method to push changes to the UI.
    public void requestRender(String serverName){
        for(int i=0; i<renderers.size(); i++){
            OnDemandRenderer temp = (OnDemandRenderer)renderers.get(i);
            if(temp.getName().equals(serverName)){
                temp.requestRender();
            }
        }
    }

    public void removeFromRenderer(User user){
        for(int i=0; i<renderers.size(); i++){
            OnDemandRenderer temp = (OnDemandRenderer)renderers.get(i);
            if(temp.contains(user)){
                temp.remove(user);
            }
        }
    }

    public void addToRenderer(UserBean user){
        for(int i=0; i<renderers.size(); i++){
            OnDemandRenderer temp = (OnDemandRenderer)renderers.get(i);
            if(temp.getName().equals(user.selectedServer.getName())){
                temp.add(user);
            }
        }
    }

    // After login, this method will return a list of servers available to a user
    // based on the user role.  User roles are listed in user.properties.
    public List getServerList(int roleNumber){
        List serverList = new ArrayList();
        switch(roleNumber){
        // Fall through is used to give roles access to the lower roles.
        // 1 is ROLE_SUPERVISOR and 2 is ROLE_USER.
        case 1:
            serverList.add(new SelectItem(servers.getServers()[0], servers.getServers()[0].getName()));
        case 2:
            serverList.add(new SelectItem(servers.getServers()[1], servers.getServers()[1].getName()));
            serverList.add(new SelectItem(servers.getServers()[2], servers.getServers()[2].getName()));
            serverList.add(new SelectItem(servers.getServers()[3], servers.getServers()[3].getName()));
            serverList.add(new SelectItem(servers.getServers()[4], servers.getServers()[4].getName()));
            serverList.add(new SelectItem(servers.getServers()[5], servers.getServers()[5].getName()));
            serverList.add(new SelectItem(servers.getServers()[6], servers.getServers()[6].getName()));
        default:            
        }
        return serverList;
    }

}
