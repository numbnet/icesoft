package com.icesoft.icefaces.samples.security;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Queues model, this class contains most of the logic for the simulation.
 */
public class Queues {

        private static Log log = LogFactory.getLog(Queues.class);
    // list of queues
    protected ArrayList queues;

    // This Thread is used to update queue properties, the update is
    // called every second.
    private Thread queueStatusUpdateThread;
    private boolean running = true;

    // sort column names
    private static String queueNameColumnName = "Queue Name";
    private static String rcvrsColumnName = "Rcvrs";
    private static String msgsColumnName = "Msgs";
    private static String sizeColumnName = "Size";
    
    //Queues Statistics
    private int deliveredMsgsTotal = 0;
    private int inTransitMsgsTotal = 0;
    private int maxDeliveredTotal = 0;
    private int prefetchTotal = 0;
    private int liveConsumersTotal = 0;

    protected int nameCount = 0;
    
    protected Server server;

    public Queues(String[] queueNames) {
        queues = new ArrayList(queueNames.length);
        for (int i=0; i<queueNames.length; i++){
            addNewQueue(queueNames);
        }
        nameCount = 0;
        startTimer();
    }
    
    public void init(Server server){
        this.server = server;
        for(int i=0; i<queues.size(); i++){
            ((Queue)queues.get(i)).init(this);
        }
    }
    
    //Getters
    public String getQueueNameColumnName() { return queueNameColumnName; }
    public String getRcvrsColumnName() { return rcvrsColumnName; }
    public String getMsgsColumnName() { return msgsColumnName; }
    public String getSizeColumnName() { return sizeColumnName; }
    public int getDeliveredMsgsTotal() { return deliveredMsgsTotal; }
    public int getInTransitMsgsTotal() { return inTransitMsgsTotal; }
    public int getLiveConsumersTotal() { return liveConsumersTotal; }
    public int getMaxDeliveredTotal() { return maxDeliveredTotal; }
    public int getPrefetchTotal() { return prefetchTotal; }
    
    //Setters
    public void setDeliveredMsgsTotal(int deliveredMsgsTotal) { this.deliveredMsgsTotal = deliveredMsgsTotal; }
    public void setInTransitMsgsTotal(int inTransitMsgsTotal) { this.inTransitMsgsTotal = inTransitMsgsTotal; }
    public void setLiveConsumersTotal(int liveConsumersTotal) { this.liveConsumersTotal = liveConsumersTotal; }
    public void setMaxDeliveredTotal(int maxDeliveredTotal) { this.maxDeliveredTotal = maxDeliveredTotal; }
    public void setPrefetchTotal(int prefetchTotal) { this.prefetchTotal = prefetchTotal; }

    public ArrayList getQueues() {
        return queues;
    }

    private void addNewQueue(String[] queueNames){
        Queue queue = new Queue();
        queue.generateData(queueNames[nameCount]);
        nextQueueName();

        queues.add(queue);
        deliveredMsgsTotal += queue.getDeliveredMsgs();
        inTransitMsgsTotal += queue.getInTransitMsgs();
        maxDeliveredTotal += queue.getMaxDelivered();
        prefetchTotal += queue.getPrefetch();
        liveConsumersTotal += queue.getLiveConsumers();        
    }
    
    protected synchronized int nextQueueName(){
        return nameCount++;
    }

    public void startTimer(){
        // start the timer, every second the simulated data will be updated.
        queueStatusUpdateThread = new Thread(new Updater());
        queueStatusUpdateThread.start(); 
    }
    
    public void stopTimer(){
        running = false;
    }

    private class Updater implements Runnable{

        public void run() {
            while(running){
                deliveredMsgsTotal = 0;
                inTransitMsgsTotal = 0;
                maxDeliveredTotal = 0;
                prefetchTotal = 0;
                liveConsumersTotal = 0;
                
                Queue tempQueue;
                for (int i=0; i<queues.size(); i++){
                    tempQueue = (Queue)queues.get(i);
                    tempQueue.updateStatus();
                    deliveredMsgsTotal += tempQueue.getDeliveredMsgs();
                    inTransitMsgsTotal += tempQueue.getInTransitMsgs();
                    maxDeliveredTotal += tempQueue.getMaxDelivered();
                    prefetchTotal += tempQueue.getPrefetch();
                    liveConsumersTotal += tempQueue.getLiveConsumers();
                }
                try{
                    int temp = (Queue.random.nextInt(3)+1)*1000;
                    Thread.sleep(temp);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                // Race condition here on logout, sometimes the clientController appears
                // to be null
                try {
                    server.servers.clientController.requestRender(server.getName());
                } catch (RuntimeException rte) {
                    if (log.isDebugEnabled()) {
                        log.debug("NPE caught during render ");
                    } 
                }
            }
        }
    }

}
