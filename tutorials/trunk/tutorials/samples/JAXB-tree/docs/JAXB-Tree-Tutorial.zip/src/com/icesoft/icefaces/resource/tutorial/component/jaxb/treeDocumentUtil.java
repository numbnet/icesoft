/*
 * treeDocumentUtil.java
 *
 * Created on April 17, 2007, 2:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.icesoft.icefaces.resource.tutorial.component.jaxb;

/**
 *
 * @author dnorthcott
 */
public class treeDocumentUtil {
    
    /** Creates a new instance of treeDocumentUtil */
    public treeDocumentUtil() {
    }
    
}
