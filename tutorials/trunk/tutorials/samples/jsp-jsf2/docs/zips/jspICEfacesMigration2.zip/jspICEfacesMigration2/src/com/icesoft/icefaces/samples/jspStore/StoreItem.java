package com.icesoft.icefaces.samples.jspStore;

import java.text.NumberFormat;

import javax.faces.event.ActionEvent;

/**
 * Item for sale in the JSP-JSF store.
 */
public class StoreItem {
    
    private String label, sku;
    private int quantity, purchasedQuantity;
    private double price;
    private static NumberFormat numberFormatter;
    private Store store;
    
    /**
     * Default constructor.
     */
    public StoreItem() {
    }
    
    /**
     * Instantiates a new StoreItem and all of its properties.
     * 
     * @param label the label used to identify the item in the store GUI
     * @param price the price of the item
     * @param quantity the initial amount of the item
     * @param sku the unique identifier used for a hash key
     */
    public StoreItem(Store store, String label, double price, int quantity, String sku){
    	numberFormatter = NumberFormat.getCurrencyInstance();
        this.store = store;
        this.label = label;
        this.price = price;
        this.quantity = quantity;
        this.sku = sku;
    }
    
    /**
     * Members for manipulating quantities;
     */
     public void increaseQuantity(){
        if (purchasedQuantity > 0) {
	    	quantity++;
	        purchasedQuantity--;
        }
    }
    
    public void decreaseQuantity(){
        if (quantity > 0){
            quantity--;
            purchasedQuantity++;
        }
    }
    public void increaseInventory(){
    	quantity++;
    }
    
    public void decreaseInventory(){
        if (quantity > 0){
            quantity--;
        }
    }

    /**
     * Action Listeners
     */
    public void addToCart(ActionEvent e){
    	decreaseQuantity();
    }
    public void removeFromCart(ActionEvent e){
    	increaseQuantity();
    }
 
    /**
     * Bean getters and setters
     */
   public String getLabel() {
        return label;
    }

    public String getPrice() {
        return numberFormatter.format(price);
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getPurchasedQuantity() {
        return purchasedQuantity;
    }

    public double getPurchasedTotalPrice() {
        return purchasedQuantity*price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void resetQuantity() {
        quantity += purchasedQuantity;
        purchasedQuantity = 0;
    }

    public String getSku() {
        return sku;
    }
    
    public String getSubTotal(){
        return numberFormatter.format(purchasedQuantity * price);
    }

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}
}
