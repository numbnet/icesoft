/*
 * icePage1.java
 *
 * Created on 4-Dec-2008, 3:55:57 PM
 * Copyright maryka
 */
package twopagecrudtable;

import com.icesoft.faces.component.ext.RowSelectorEvent;
import com.icesoft.faces.component.jsfcl.data.CachedRowSetSortableDataModel;
//import com.icesoft.faces.component.jsfcl.data.DefaultTableDataModel;
import com.sun.data.provider.RowKey;
import com.sun.data.provider.impl.CachedRowSetDataProvider;
import com.sun.rave.faces.data.CachedRowSetDataModel;
//import com.sun.rave.web.ui.appbase.AbstractPageBean;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.TreeMap;
import javax.faces.FacesException;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 */
public class IcePage1 extends Page1 {
    // <editor-fold defaultstate="collapsed" desc="Managed Component Definition">
    private int __placeholder;

    /**
     * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
     * This method is automatically generated, so any user-specified code inserted
     * here is subject to being replaced.</p>
     */
    private void _init() throws Exception {
        //dataTable1Model.setCachedRowSet((javax.sql.rowset.CachedRowSet) getValue("#{SessionBean1.tripRowSet}"));
        dataTable1SortableDataModel.setWrappedData((javax.sql.rowset.CachedRowSet) getValue("#{SessionBean1.tripRowSet}"));
        triptypeDataProvider.setCachedRowSet((javax.sql.rowset.CachedRowSet) getValue("#{SessionBean1.triptypeRowSet}"));
    }
    private CachedRowSetDataModel dataTable1Model = new CachedRowSetDataModel();

    public CachedRowSetDataModel getDataTable1Model() {
        return dataTable1Model;
    }

    public void setDataTable1Model(CachedRowSetDataModel crsdm) {
        this.dataTable1Model = crsdm;
    }
    private CachedRowSetSortableDataModel dataTable1SortableDataModel = new CachedRowSetSortableDataModel();

    public CachedRowSetSortableDataModel getDataTable1SortableDataModel() {
        return dataTable1SortableDataModel;
    }

    public void setDataTable1SortableDataModel(CachedRowSetSortableDataModel crssdm) {
        this.dataTable1SortableDataModel = crssdm;
    }


    // State required to maintain sort header
    private boolean sortAscending;
    private String sortColumn;

    // State to maintain sort header;
    public boolean isSortAscending() {
        return sortAscending;
    }
    public void setSortAscending(boolean ascending) {
        sortAscending = ascending;
        if (ascending != dataTable1SortableDataModel.isAscending()) {
            dataTable1SortableDataModel.setAscending(ascending);
        }
        if (getSessionBean1().getSortColumn() != null) {
            dataTable1SortableDataModel.setSort(getSessionBean1().getSortColumn());
        }
    }
    public String getSortColumn() {
        return sortColumn;
    }
    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    } 
    // </editor-fold>

    /**
     * <p>Construct a new Page bean instance.</p>
     */
    public IcePage1() {
    }

    /**
     * <p>Callback method that is called whenever a page is navigated to,
     * either directly via a URL, or indirectly via page navigation.
     * Customize this method to acquire resources that will be needed
     * for event handlers and lifecycle methods, whether or not this
     * page is performing post back processing.</p>
     * 
     * <p>Note that, if the current request is a postback, the property
     * values of the components do <strong>not</strong> represent any
     * values submitted with this request.  Instead, they represent the
     * property values that were saved for this view when it was rendered.</p>
     */
    public void init() {
        // Perform initializations inherited from our superclass
        super.init();
        // Perform application initialization that must complete
        // *before* managed components are initialized
        // TODO - add your own initialiation code here
            
        // <editor-fold defaultstate="collapsed" desc="Managed Component Initialization">
        // Initialize automatically managed components
        // *Note* - this logic should NOT be modified
        try {
            _init();
        } catch (Exception e) {
            log("icePage1 Initialization Failure", e);
            throw e instanceof FacesException ? (FacesException) e: new FacesException(e);
        }
        
        // </editor-fold>
        // Perform application initialization that must complete
        // *after* managed components are initialized
        // TODO - add your own initialization code here
    }

    /**
     * <p>Callback method that is called after the component tree has been
     * restored, but before any event processing takes place.  This method
     * will <strong>only</strong> be called on a postback request that
     * is processing a form submit.  Customize this method to allocate
     * resources that will be required in your event handlers.</p>
     */
    public void preprocess() {
        super.preprocess();
    }

    /**
     * <p>Callback method that is called just before rendering takes place.
     * This method will <strong>only</strong> be called for the page that
     * will actually be rendered (and not, for example, on a page that
     * handled a postback and then navigated to a different page).  Customize
     * this method to allocate resources that will be required for rendering
     * this page.</p>
     */
    public void prerender() {
        super.prerender();
    }

    /**
     * <p>Callback method that is called after rendering is completed for
     * this request, if <code>init()</code> was called (regardless of whether
     * or not this was the page that was actually rendered).  Customize this
     * method to release resources acquired in the <code>init()</code>,
     * <code>preprocess()</code>, or <code>prerender()</code> methods (or
     * acquired during execution of an event handler).</p>
     */
    public void destroy() {
        super.destroy();
    }

    public void personDropDownProcessValueChange(ValueChangeEvent event) {

       if (event.getPhaseId() != PhaseId.INVOKE_APPLICATION) {
           event.setPhaseId(PhaseId.INVOKE_APPLICATION);
           event.queue();
       } else {
           super.personDropDown_processValueChange(event);
           dataTable1SortableDataModel.setWrappedData(getSessionBean1().getTripRowSet());
           currentRowData = null;
           selectedPanel = "noSelection";
       }
    }

    public String updateButtonAction() {

        //find current tripID and update trip data
        Integer tid = (Integer) detailRowData.get("TRIP.TRIPID");
        RowKey rowKey = getTripDataProvider().findFirst("TRIP.TRIPID", tid);
        try {
            saveTripData(rowKey);
            //update dataModel for dataTable with new modified data
            dataTable1SortableDataModel.setWrappedData(getSessionBean1().getTripRowSet());
        } catch (Exception e) {
                error("Cannot update trip:data " + e);
        }

        // reset state to selected
        selectedPanel = "selected";
        return null;
    }

    public String cancelUpdateButtonAction() {
        detailRowData = (TreeMap) currentRowData.clone();
        selectedPanel = "selected";
        clearInputComponents();
        return null;
    }

    public String deleteButtonAction() {
        RowKey key = getTripDataProvider().findFirst("TRIP.TRIPID", currentRowData.get("TRIP.TRIPID"));
        setCurrentRowKey(key);
        //remove record from cachedRowSet
        String returnVal = super.deleteButton_action();
        //update model and adjust state
        dataTable1SortableDataModel.setWrappedData(getSessionBean1().getTripRowSet());
        currentRowData = null;
        selectedPanel = "noSelection";
        return returnVal;
    }

    public String createButtonAction() {
        // New details;
        detailRowData = new TreeMap();
        try {
            detailRowData.put("TRIP.TRIPID", nextPK());
        } catch (SQLException sqle) {
            getFacesContext().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Problem getting next trip ID.", null));
        }
        detailRowData.put("TRIP.PERSONID", getCurrentPersonId());
        detailRowData.put("TRIP.DEPDATE",  new java.util.Date());
        detailRowData.put("TRIP.DEPCITY", "");
        detailRowData.put("TRIP.DESTCITY", "");
        detailRowData.put("TRIP.TRIPTYPEID", new Integer(1));
        currentRowData = null;

        // Go to create state;
        selectedPanel = "create";
        return null;
    }

    public String cancelCreateButtonAction() {
        detailRowData = null;
        currentRowData = null;
        selectedPanel = "noSelection";
        clearInputComponents();
        return null;
    }

    public String saveCreateButtonAction() {
        CachedRowSetDataProvider tripDataProvider = getTripDataProvider();
        if ( tripDataProvider.canAppendRow() ) {
            try {
                RowKey rowKey = tripDataProvider.appendRow();
                tripDataProvider.setCursorRow(rowKey);
                tripDataProvider.setValue("TRIP.TRIPID", rowKey,  detailRowData.get("TRIP.TRIPID"));
                saveTripData(rowKey);
                tripDataProvider.commitChanges();
                tripDataProvider.refresh();
            } catch (Exception e) {
                error("Cannot append new trip: " + e);
            }
        } else {
                error("Cannot append a new row");
        }
        //update dataModel and adjust state;
        dataTable1SortableDataModel.setWrappedData(getSessionBean1().getTripRowSet());
        selectedPanel = "selected";
        currentRowData = (TreeMap) detailRowData.clone();
        // Need to create new Date object to avoid shallow clone;
        java.sql.Date date = (java.sql.Date) detailRowData.get("TRIP.DEPDATE");
        currentRowData.put("TRIP.DEPDATE", new Date(date.getTime()));
        return null;
    }

    /*  Logic to clear input on cancel.  Read more about this problem in JSF at
        http://wiki.apache.org/myfaces/ClearInputComponents */
    private void clearInputComponents() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        UIViewRoot uiViewRoot = facesContext.getViewRoot();
        UIComponent inputContainer = (UIComponent) uiViewRoot.findComponent("form1:tripPanel");
        if (inputContainer != null) {
            List children = inputContainer.getChildren();
            ListIterator it = children.listIterator();
            while (it.hasNext()) {
                Object next = it.next();
                if (next instanceof UIInput) {
                    UIInput uiInput = (UIInput) next;
                    uiInput.resetValue();
                }
            }
        }
    }


    private void saveTripData(RowKey rowKey) {
        CachedRowSetDataProvider tripDataProvider = getTripDataProvider();
        tripDataProvider.setValue("TRIP.PERSONID", rowKey, detailRowData.get("TRIP.PERSONID"));
        Date date = (Date) detailRowData.get("TRIP.DEPDATE");
        tripDataProvider.setValue("TRIP.DEPDATE", rowKey, new java.sql.Date(date.getTime()));
        tripDataProvider.setValue("TRIP.DEPCITY", rowKey, detailRowData.get("TRIP.DEPCITY"));
        tripDataProvider.setValue("TRIP.DESTCITY", rowKey, detailRowData.get("TRIP.DESTCITY"));
        tripDataProvider.setValue("TRIP.TRIPTYPEID", rowKey, detailRowData.get("TRIP.TRIPTYPEID"));
        tripDataProvider.commitChanges();
        tripDataProvider.refresh();
    }

    //These members are required to make design view work
    public CachedRowSetDataProvider getPersonDataProvider() {
        return super.getPersonDataProvider();
    }

    public void setPersonDataProvider(CachedRowSetDataProvider crsdp) {
        super.setPersonDataProvider(crsdp);
    }

    public Integer getCurrentPersonId() {
        return super.getCurrentPersonId();
    }
    public void setCurrentPersonId(Integer currentPersonId) {
        super.setCurrentPersonId(currentPersonId);
    }

    // State to maintain currently selected row;
    private TreeMap currentRowData;
    public TreeMap getCurrentRowData() {
        return currentRowData;
    }
    public void setCurrentRowData(TreeMap currentRowData) {
        this.currentRowData = currentRowData;
    }

    // State to maintain detail panel state
    private TreeMap detailRowData;
    public TreeMap getDetailRowData() {
        return detailRowData;
    }
    public void setDetailRowData(TreeMap detailRowData) {
        this.detailRowData = detailRowData;
    }

    public void rowSelector1_processAction(RowSelectorEvent rse) {
        currentRowData = (TreeMap) dataTable1SortableDataModel.getRowData();
        detailRowData = (TreeMap) currentRowData.clone();
        // Need to create new Date object to avoid shallow clone;
        java.sql.Date date = (java.sql.Date) currentRowData.get("TRIP.DEPDATE");
        detailRowData.put("TRIP.DEPDATE", new Date(date.getTime()));
        selectedPanel = "selected";
    }

    public boolean isRowSelected() {
        if (currentRowData == null) {
            return false;
        }
        TreeMap rowData = (TreeMap) dataTable1SortableDataModel.getRowData();
        Integer currentTrip = (Integer)rowData.get("TRIP.TRIPID");
        Integer selectedTrip = (Integer) currentRowData.get("TRIP.TRIPID");
        return (currentTrip.equals(selectedTrip));
    }

    public void setRowSelected(boolean selected) {
    }

   // State for detail panel
    private CachedRowSetDataProvider triptypeDataProvider = new CachedRowSetDataProvider();

    public CachedRowSetDataProvider getTriptypeDataProvider() {
        return triptypeDataProvider;
    }

    public void setTriptypeDataProvider(CachedRowSetDataProvider crsdp) {
        this.triptypeDataProvider = crsdp;
    }

    // Getter for rendering the tripPanel
    public boolean isTripSelected() {
        return (currentRowData != null || selectedPanel.equals("create"));
    }

    // Button Panel Stack State
    public String selectedPanel = "noSelection";
    public String getSelectedPanel() {
        return selectedPanel;
    }

    public void setSelectedPanel(String selectedPanel) {
        this.selectedPanel = selectedPanel;
    }

    // Row Editing state;
    public boolean isTripBeingEdited() {
        if (selectedPanel.equals("create") || selectedPanel.equals("update"))
            return true;
        else
            return false;
    }

    // Update detected handlers;
    public void depDateUpdateDetected (ValueChangeEvent event) {
        detailRowData.put("TRIP.DEPDATE",  event.getNewValue());
        updateDetected();
    }

    public void depCityUpdateDetected (ValueChangeEvent event) {
        detailRowData.put("TRIP.DEPCITY",  event.getNewValue());
        updateDetected();
    }

    public void destCityUpdateDetected (ValueChangeEvent event) {
        detailRowData.put("TRIP.DESTCITY",  event.getNewValue());
        updateDetected();
    }

    public void tripTypeUpdateDetected (ValueChangeEvent event) {
        detailRowData.put("TRIP.TRIPTYPEID",  event.getNewValue());
        updateDetected();
    }

    private void updateDetected( ) {
        if (selectedPanel.equals("selected") || selectedPanel.equals("update")) {
            if (rowDataChanged()) {
                selectedPanel = "update";
            } else {
                selectedPanel = "selected";
            }
        }
    }

    private boolean rowDataChanged() {
        if (currentRowData == null || detailRowData == null) {
            return false;
        }
        Date date1 = (Date) currentRowData.get("TRIP.DEPDATE");
        Date date2 = (Date) detailRowData.get("TRIP.DEPDATE");
        if (!date1.equals(date2)){
            return true;
        }

        String string1 = (String) currentRowData.get("TRIP.DEPCITY");
        String string2 = (String) detailRowData.get("TRIP.DEPCITY");
        if (string1 == null || string2 == null || !string1.equals(string2)) {
            return true;
        }
        string1 = (String) currentRowData.get("TRIP.DESTCITY");
        string2 = (String) detailRowData.get("TRIP.DESTCITY");
        if (string1 == null || string2 == null || !string1.equals(string2)) {
            return true;
        }
        Integer int1 = (Integer) currentRowData.get("TRIP.TRIPTYPEID");
        Integer int2 = (Integer) detailRowData.get("TRIP.TRIPTYPEID");
        if (!int1.equals(int2)) {
            return true;
        }
        return false;
    }

    private Integer nextPK() throws java.sql.SQLException {
        // create a new rowset
        com.sun.sql.rowset.CachedRowSetXImpl pkRowSet = new com.sun.sql.rowset.CachedRowSetXImpl();
        try {
            // set the rowset to use the Travel database
            pkRowSet.setDataSourceName("java:comp/env/jdbc/TRAVEL_ApacheDerby");
            // find the highest person id and add one to it
            pkRowSet.setCommand("SELECT MAX(TRAVEL.TRIP.TRIPID) + 1 FROM TRAVEL.TRIP");
            pkRowSet.setTableName("TRAVEL.TRIP");
            // execute the rowset -- which will contain a single row and single column
            pkRowSet.execute();
            pkRowSet.next();
            // get the key
            int counter = pkRowSet.getInt(1);
            return new Integer(counter);
        } catch (Exception e) {
            error("Error fetching Max(TRIPID)+1 : " + e.getMessage());
        } finally {
            pkRowSet.close();
        }
        return null;
    }

}

