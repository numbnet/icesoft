package twopagecrudtable;

import java.util.TimeZone;
import javax.faces.convert.DateTimeConverter;

public class DateConverter extends DateTimeConverter {
   public DateConverter() {
       super();
       setTimeZone(TimeZone.getDefault());
   }
}
