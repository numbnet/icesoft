package org.testng.remote.strprotocol;


/**
 * Marker interface for usage with remote listeners.
 * 
 * @author <a href='mailto:the_mindstorm[at]evolva[dot]ro'>Alexandru Popescu</a>
 */
public interface IMessage {
}
