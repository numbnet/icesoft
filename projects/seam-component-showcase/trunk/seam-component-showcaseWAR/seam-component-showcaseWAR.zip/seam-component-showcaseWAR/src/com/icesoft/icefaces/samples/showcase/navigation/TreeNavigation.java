/*
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * "The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations under
 * the License.
 *
 * The Original Code is ICEfaces 1.5 open source software code, released
 * November 5, 2006. The Initial Developer of the Original Code is ICEsoft
 * Technologies Canada, Corp. Portions created by ICEsoft are Copyright (C)
 * 2004-2006 ICEsoft Technologies Canada, Corp. All Rights Reserved.
 *
 * Contributor(s): _____________________.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"
 * License), in which case the provisions of the LGPL License are
 * applicable instead of those above. If you wish to allow use of your
 * version of this file only under the terms of the LGPL License and not to
 * allow others to use your version of this file under the MPL, indicate
 * your decision by deleting the provisions above and replace them with
 * the notice and other provisions required by the LGPL License. If you do
 * not delete the provisions above, a recipient may use your version of
 * this file under either the MPL or the LGPL License."
 *
 */

package com.icesoft.icefaces.samples.showcase.navigation;


import com.icesoft.icefaces.samples.showcase.util.StyleBean;


import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.seam.annotations.In;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import org.jboss.seam.ScopeType;
import java.util.Enumeration;
import java.io.Serializable;
/**
 * <p>The TreeNavigation class is the backing bean for the showcase navigation
 * tree on the left hand side of the application. Each node in the tree is made
 * up of a PageContent which is responsible for the navigation action when a
 * tree node is selected.</p>
 * <p/>
 * <p>When the Tree component binding takes place the tree nodes are initialized
 * and the tree is built.  Any addition to the tree navigation must be made to
 * this class.</p>
 *
 * @since 0.3.0
 */
@Scope(ScopeType.SESSION)    
@Name("treeNavigation")
public class TreeNavigation implements Serializable{
	   private static Log log =
           LogFactory.getLog(TreeNavigation.class);   
    // binding to component
// 	@In(required=false, value="#{uiComponent['navigationTreeId']}")
//    private Tree treeComponent;

    // bound to components value attribute
    private DefaultTreeModel model;

    // root node of tree, for delayed construction
    private DefaultMutableTreeNode rootTreeNode;

    private PageContentBean currentPageContent;
    
    // map of all navigation backing beans.
//    @In(create=true) @Out
//    private NavigationBean navigationBean;
    
    @In(create=true) @Out 
    private StyleBean styleBean;
    
//    @Logger 
//    private Log log;

    // initialization flag
    private boolean isInitiated=false;

    // folder icons for branch nodes
    private String themeBranchContractedIcon;
    private String themeBranchExpandedIcon;

    /**
     * Default constructor of the tree.  The root node of the tree is created at
     * this point.
     */
    public TreeNavigation() {
        // build root node so that children can be attached
    	log.info("TreeNavigation constructor");
        PageContentBean rootObject = new PageContentBean(this);
        rootObject.setMenuDisplayText("menuDisplayText.componentSuiteMenuGroup");
        rootObject.setMenuContentTitle(
                "submenuContentTitle.componentSuiteMenuGroup");
        rootObject.setMenuContentInclusionFile("./content/splashComponents.xhtml");
        rootObject.setTemplateName("splashComponentsPanel");
        rootObject.setPageContent(true);
        rootTreeNode = new DefaultMutableTreeNode(rootObject);
        rootObject.setWrapper(rootTreeNode);
 //       rootObject.setNavigationSelection(navigationBean);
        

        model = new DefaultTreeModel(rootTreeNode);
        this.currentPageContent = rootObject;
  //      log.info("StyleBean is :"+styleBean.getCurrentStyle());
        // StyleBean binding
//        Application application =
//                FacesContext.getCurrentInstance().getApplication();
//        StyleBean styleBean =
//                ((StyleBean) application.createValueBinding("#{styleBean}").
//                        getValue(FacesContext.getCurrentInstance()));

        // provide StyleBean with reference to the tree navigation for folder icon updates
//        if (styleBean!=null)
//        	styleBean.registerTree(this);
//        else log.info("styleBean is null");

        // xp folders (default theme)
        themeBranchContractedIcon = StyleBean.XP_BRANCH_CONTRACTED_ICON;
        themeBranchExpandedIcon = StyleBean.XP_BRANCH_EXPANDED_ICON;
        init();
    }

    /**
     * Iterates over each node in the navigation tree and sets the icon based on
     * the current theme. This is necessary for the change to register with the
     * component.
     *
     * @param currentStyle the theme on which the folder icons are based
     */
    public void refreshIcons(String currentStyle) {

        // set the folder icon based on the StyleBean theme
        if (currentStyle.equals("xp")) {
            themeBranchContractedIcon = StyleBean.XP_BRANCH_CONTRACTED_ICON;
            themeBranchExpandedIcon = StyleBean.XP_BRANCH_EXPANDED_ICON;
        } else if (currentStyle.equals("royale")) {
            themeBranchContractedIcon = StyleBean.ROYALE_BRANCH_CONTRACTED_ICON;
            themeBranchExpandedIcon = StyleBean.ROYALE_BRANCH_EXPANDED_ICON;
        }
        // invalid theme
        else {
            return;
        }

        // get each tree node for iteration
        Enumeration enumTree = rootTreeNode.depthFirstEnumeration();
        PageContentBean temp = null;

        // set the icon on each tree node
        while (enumTree.hasMoreElements()) {
            temp = ((PageContentBean) ((DefaultMutableTreeNode) enumTree
                    .nextElement()).getUserObject());

            if (temp != null) {
                temp.setBranchContractedIcon(themeBranchContractedIcon);
                temp.setBranchExpandedIcon(themeBranchExpandedIcon);
            }
        }
    }

    /**
     * Utility method to build the entire navigation tree.
     */
    private void init() {
        // set init flag
    	log.info("init()");
        isInitiated = true;
        if (rootTreeNode == null){
        	log.info("rootTreeNode is null");
        	
        }
        if (rootTreeNode != null) {

                PageContentBean branchObject =
                        (PageContentBean) rootTreeNode.getUserObject();

                // assign the initialized navigation bean, so that we can enable panel navigation
 //               navigationBean = (NavigationBean) navigationObject;

                // set this node as the default page to view

  //              branchObject.setNavigationSelection(currentPageContent);

                /**
                 * Generate the backing bean for each tree node and put it all together
                 */

                // theme menu item --
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.themesSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.themesSubmenuItem");
                branchObject.setTemplateName("splashThemesPanel");
 //               branchObject.setNavigationSelection(navigationBean);
                branchObject.setMenuContentInclusionFile("./content/splashThemes.xhtml");

                DefaultMutableTreeNode branchNode =
                        new DefaultMutableTreeNode(branchObject);
                branchObject.setLeaf(
                        true); // leaf nodes must be explicitly set - support lazy loading
                branchObject.setWrapper(branchNode);
                // finally add the new custom component branch
                rootTreeNode.add(branchNode);

                // Component menu item
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "menuDisplayText.componentsMenuGroup");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.componentsMenuGroup");


                branchObject.setTemplateName("splashComponentsPanel");
//                branchObject.setNavigationSelection(navigationBean);
                branchObject.setPageContent(false);
                branchNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(branchNode);
                // finally add the new custom component branch
                rootTreeNode.add(branchNode);

                // component menu -> Text Entry
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.textFieldsSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.textFieldsSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/textFields.xhtml");
                branchObject.setTemplateName("textFieldsContentPanel");
                DefaultMutableTreeNode leafNode =
                        new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Selection
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.selectionTagsSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.selectionTagsSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/selectionTags.xhtml");
                branchObject.setTemplateName("selectionTagsContentPanel");
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Button & Links
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.buttonsAndLinksSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.buttonsAndLinksSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/buttonsAndLinks.xhtml");
                branchObject.setTemplateName("buttonsAndLinksContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Auto Complete
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.autoCompleteSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.autoCompleteSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/autoComplete.xhtml");
                branchObject.setTemplateName("autoCompleteContentPanel");
  //              branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Drag and Drop
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.dragDropSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.dragDropSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/dragDrop.xhtml");
                branchObject.setTemplateName("dragDropContentPanel");
 //               branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Calendar
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.selectInputDateComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.selectInputDateComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/selectInputDate.xhtml");
                branchObject.setTemplateName("selectInputDateContentPanel");
 //               branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Tree
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.treeComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.treeComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/tree.xhtml");
                branchObject.setTemplateName("treeContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> MenuBar
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.menuBarSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.menuBarSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/menuBar.xhtml");
                branchObject.setTemplateName("menuBarContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                //component menu -> Effects
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.effectsSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.effectsSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/effects.xhtml");
                branchObject.setTemplateName("effectsContentPanel");
  //              branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                //component menu -> Connection Status
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.connectionStatusSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.connectionStatusSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/connectionStatus.xhtml");
                branchObject.setTemplateName("connectionStatusContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Table
                branchObject = new PageContentBean(this);
                branchObject.setExpanded(false);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.tableComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.tableComponentSubmenuItem");

                branchObject.setTemplateName("splashTablesPanel");
//                branchObject.setNavigationSelection(navigationBean);
                branchObject.setPageContent(false);
                DefaultMutableTreeNode branchNode2 =
                        new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(branchNode2);
                // finally add the new custom component branch
                branchNode.add(branchNode2);

                // component menu -> Table -> Table
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.tableComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.tableComponentSubmenuItem");
                 branchObject.setMenuContentInclusionFile("./components/table.xhtml");
                branchObject.setTemplateName("tableContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode2.add(leafNode);

                // component menu -> Table -> Columns
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.columnsComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.columnsComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/tableColumns.xhtml");
                branchObject.setTemplateName("columnsContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode2.add(leafNode);

                // component menu -> Table -> Sortable Header
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.dataSortHeaderComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.dataSortHeaderComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/commandSortHeader.xhtml");
                branchObject.setTemplateName("commandSortHeaderContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode2.add(leafNode);

                // component menu -> Table -> Data Header
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.dataScrollerComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.dataScrollerComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/dataPaginator.xhtml");
                branchObject.setTemplateName("tablePaginatorContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode2.add(leafNode);

                // component menu -> Table -> TableExpandable
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.tableExpandableComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.tableExpandableComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/tableExpandable.xhtml");
                branchObject.setTemplateName("tableExpandableContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode2.add(leafNode);

                // component menu -> Table -> TableRowSelec5tion
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.tableRowSelectionComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.tableRowSelectionComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/tableRowSelection.xhtml");
                branchObject.setTemplateName("tableRowSelectionContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode2.add(leafNode);

                // component menu -> Progress Indicator
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.outputProgressComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.outputProgressComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/outputProgress.xhtml");
                branchObject.setTemplateName("outputProgressContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> File Upload
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.inputFileComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.inputFileComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/inputFile.xhtml");
                branchObject.setTemplateName("inputFileContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Chart
                branchObject = new PageContentBean(this);
                branchObject.setExpanded(false);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.chartComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.chartComponentSubmenuItem");

                branchObject.setTemplateName("splashChartsPanel");
//                branchObject.setNavigationSelection(navigationBean);
                branchObject.setPageContent(false);
                DefaultMutableTreeNode branchNode3 =
                        new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(branchNode3);
                // finally add the new custom component branch
                branchNode.add(branchNode3);

                // component menu -> Chart -> Chart
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.chartComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.chartComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/outputChart/chart.xhtml");
                branchObject.setTemplateName("chartPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode3.add(leafNode);

                // component menu -> Chart -> Dynamic Chart
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.dynamicChartComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.dynamicChartComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/outputChart/dynamicChart.xhtml");
                branchObject.setTemplateName("dynamicChartPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode3.add(leafNode);

                // component menu -> Chart -> Combined Chart
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.combinedChartComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.combinedChartComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./components/outputChart/combinedChart.xhtml");
                branchObject.setTemplateName("combinedChartPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode3.add(leafNode);

                // Layout Panels menu item
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.layoutPanelMenuGroup");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.layoutPanelMenuGroup");
                branchObject.setTemplateName("splashLayoutsPanelsPanel");
//                branchObject.setNavigationSelection(navigationBean);
                branchObject.setPageContent(false);
                branchNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(branchNode);
                // finally add the new custom component branch
                rootTreeNode.add(branchNode);

                // Layout Panels menu -> Border Panel
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.borderLayoutComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.borderLayoutComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./layoutPanels/panelBorder.xhtml");
                branchObject.setTemplateName("panelBorderContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // Layout Panels menu -> Panel stack
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.panelStackComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.panelStackComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./layoutPanels/panelStack.xhtml");
                branchObject.setTemplateName("panelStackContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // Layout Panels menu -> Tab Set Panel
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.tabbedComponentSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.tabbedComponentSubmenuItem");
                branchObject.setMenuContentInclusionFile("./layoutPanels/panelTabSet.xhtml");
                branchObject.setTemplateName("tabbedPaneContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);
            

                //component menu -> Popup Panel
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.panelPopupSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.panelPopupSubmenuItem");
                branchObject.setMenuContentInclusionFile("./layoutPanels/panelPopup.xhtml");
                branchObject.setTemplateName("panelPopupContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Panel Series
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.listSubmenuItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.listSubmenuItem");
                branchObject.setMenuContentInclusionFile("./layoutPanels/panelSeries.xhtml");
                branchObject.setTemplateName("listContentPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);

                // component menu -> Panel Series
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.positionedPanelItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.positionedPanelItem");
                branchObject.setMenuContentInclusionFile("./layoutPanels/positionedPanel.xhtml");
                branchObject.setTemplateName("positionPanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);
                
                // component menu -> Accordion Series
                branchObject = new PageContentBean(this);
                branchObject.setMenuDisplayText(
                        "submenuDisplayText.collapsiblePanelItem");
                branchObject.setMenuContentTitle(
                        "submenuContentTitle.collapsiblePanelItem");
                branchObject.setMenuContentInclusionFile("./layoutPanels/panelCollapsible.xhtml");
                branchObject.setTemplateName("collapsiblePanel");
//                branchObject.setNavigationSelection(navigationBean);
                leafNode = new DefaultMutableTreeNode(branchObject);
                branchObject.setWrapper(leafNode);
                branchObject.setLeaf(true);
                // finally add the new custom component branch
                branchNode.add(leafNode);
            }

 //        }

    }

    /**
     * Gets the default tree model.  This model is needed for the value
     * attribute of the tree component.
     *
     * @return default tree model used by the navigation tree
     */
    public DefaultTreeModel getModel() {
        return model;
    }

    /**
     * Sets the default tree model.
     *
     * @param model new default tree model
     */
    public void setModel(DefaultTreeModel model) {
        this.model = model;
    }

	public PageContentBean getCurrentPageContent() {
//		log.info("getCurrentPage = "+currentPageContent.getMenuDisplayText());
		return currentPageContent;
	}

	public void setCurrentPageContent(PageContentBean currentPageContent) {
		this.currentPageContent = currentPageContent;
	}

    /**
     * Gets the tree component binding.
     *
     * @return tree component binding
     */
//    public Tree getTreeComponent() {
//    	log.info("STARTING TO DUMP STACK!!");
//    	Thread.dumpStack();
//    	log.info("FINISH");
//        return treeComponent;
//    }

    /**
     * Sets the tree component binding.
     *
     * @param treeComponent tree component to bind to
     */
//    public void setTreeComponent(Tree treeComponent) {
//    	log.info("setTreeComponent");
//        this.treeComponent = treeComponent;
//        if (!isInitiated) {
//        	log.info("this was where the init was");
//           // init();
//        }
//    }
}